document.addEventListener('DOMContentLoaded', bindButtons);

    function bindButtons(){
        document.getElementById('insert').addEventListener('click', function(event){
            var req = new XMLHttpRequest();

            //Set info property values equal to the value of the corresponding text box
            var info = {name:null, price:null, stock:null, description:null};
            info.name = document.getElementById('name').value;
            info.price = document.getElementById('price').value;
            info.stock = document.getElementById('stock').value;
            info.description = document.getElementById('description').value;
            info.image = document.getElementById('image').value;
            info.cart = document.getElementById('cart').value;
            
            //Does GET based on info properties
            req.open('GET', 'http://flip3.engr.oregonstate.edu:7753/insert?name=' + info.name + '&price=' + info.price
            + '&stock=' + info.stock + '&description=' + info.description + '&image=' + info.image + '&cart=' + info.cart, true);
            req.send(null)
            
            req.addEventListener('load', function(){
                if(req.status >= 200 && req.status <= 400){
                    console.log("Product Added");
                } else {
                    console.log("Error in network request: " + req.statusText);
              }});
            event.preventDefault();
        });
    }
